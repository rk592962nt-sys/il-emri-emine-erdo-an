# İl Emri Tweet Kuyruğu

`index.html` tek başına çalışan statik bir sitedir.

## Vercel
1. Vercel'e giriş yapın.
2. Bu klasörü GitHub'a yükleyin veya Vercel'de yeni proje oluşturup klasörü deploy edin.
3. Build command gerekmez; Framework Preset olarak `Other`/Static seçilebilir.
4. Deploy sonrası Vercel size `*.vercel.app` adresi verir.

Site otomatik tweet atmaz; kullanıcı X'te açılan paylaşım ekranından gönderimi kendisi yapar.
